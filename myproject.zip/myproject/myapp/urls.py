from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('melting',views.melting, name="melting"),
    path('finishing',views.finishing, name="melting"),
    path('melting/t1',views.T1, name="table1"),
]