from django.shortcuts import redirect, render
import pandas as pd
import pandas.io.formats.style as pds
from django.contrib import messages
from . import html_tool as ht
import os 

# Create your views here.

def index(request):
    return render(request,'index.html')
def T2(request):
    return render(request,'try.html')

def T1(request):
    filepath = "./Melting-Plan/"
    file = "data"
    df = pd.read_excel(filepath+file+".xlsx")
    data = ht.write_to_html_file(df, file)
    dic ={
        'title':file,
        'data':data,
    }
    return render(request,'table.html',dic)

def melting(request):
    filepath = "./Melting-Plan/"
    file = "data"
    if request.method == 'POST':
        file = request.POST['scenario']
        if os.path.isfile(filepath+file+".xlsx") is False:
            messages.info(request,'Ther is no ...')
            file = "data"
    df = pd.read_excel(filepath+file+".xlsx")
    data = ht.write_to_html_file(df, file)
    data2 = data

    #print(data2)
    labels = ['a','b','c']
    value = [3,5,6]

    dic ={
        'title':file,
        'data':data,
        'data2':data2,
        'labels':labels,
        'value':value
    }
    return render(request,'Melting.html',dic)

def finishing(request):
    filepath = "./Melting-Plan/"
    file = "data"
    if request.method == 'POST':
        file = request.POST['scenario']
        if os.path.isfile(filepath+file+".xlsx") is False:
            messages.info(request,'Ther is no ...')
            file = "data"
    df = pd.read_excel(filepath+file+".xlsx")
    data = ht.write_to_html_file(df, file)
    data2 = data
    dic ={
        'title':file,
        'data':data,
        'data2':data2
    }
    return render(request,'finishing.html',dic)


