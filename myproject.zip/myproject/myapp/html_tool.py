import pandas as pd

def write_to_html_file(df, title=''):
    result = '''<div>
    '''
    result = '<h1 align="center"> %s </h2>\n' % title
    result += df.to_html(classes='wide', escape=False)
    result += '''</div>

'''
    result = result.replace('''<table border="1" class="dataframe wide">''','''<table id="table_id" class="display cell-border compact stripe">''')
    return result