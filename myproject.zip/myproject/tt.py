import pandas as pd
 
inputfile = '../data/electricity_data.xls'
outputfile = './electricity_data_analyze1.xls'
 
data = pd.read_excel(inputfile)
data[u'Line loss rate'] = (data[u'Power supply']-data[u'Power supply'])/data[u'Power supply']    
data[u'Line loss rate'] = data[u'Line loss rate'].apply(lambda x: format(x, '.2%'))